/*
 *  Key bindings:
 *  l          Toggles lighting
 *  a/A        Decrease/increase ambient light
 *  d/D        Decrease/increase diffuse light
 *  s/S        Decrease/increase specular light
 *  e/E        Decrease/increase emitted light
 *  n/N        Decrease/increase shininess
 *  F1         Toggle smooth/flat shading
 *  F2         Toggle local viewer mode
 *  F3         Toggle light distance (1/5)
 *  F8         Change ball increment
 *  F9         Invert bottom normal
 *  m          Toggles light movement
 *  []         Lower/rise light
 *  p          Toggles ortogonal/perspective projection
 *  o          Cycles through objects
 *  +/-        Change field of view of perspective
 *  x          Toggle axes
 *  arrows     Change view angle
 *  PgDn/PgUp  Zoom in and out
 *  0          Reset view angle
 *  ESC        Exit
 */
#include "CSCIx229.h"

int axes=1;       //  Display axes
int mode=1;       //  Projection mode
int view = 0;     //  Chnages scene rendered
int move=1;       //  Move light
int th=0;         //  Azimuth of view angle
int ph=0;         //  Elevation of view angle
int fov=55;       //  Field of view (for perspective)
int obj=0;        //  Scene/opbject selection
double asp=1;     //  Aspect ratio
double dim=15;     //  Size of world
int alpha=100;    //  Transparency
double Kth = 0; // Kelp displacement
double Fth = 0; // Fish displacment
double treelocation[5][5][3];
unsigned int texture[11];  //  Texture names
unsigned int treeTex[1]; // Stores tree texture
unsigned int skyTex[3]; // Stores sky texture
unsigned int cactusTex[1]; // stores cactus texture
unsigned int waterTex[3]; // stores water texture
unsigned int palmTex[3]; // stores palm tree textures
unsigned int pyramidTex[3]; // stores pyramid textures
unsigned int mountains[1]; // stores mountain texture
double rep=1;  //  Repetition
// Light values
int light     =   1;  // Lighting
int one       =   1;  // Unit value
int distance  =   5;  // Light distance
int inc       =  10;  // Ball increment
int smooth    =   1;  // Smooth/Flat shading
int local     =   0;  // Local Viewer Model
int emission  =   0;  // Emission intensity (%)
int ambient   =  10;  // Ambient intensity (%)
int diffuse   =  50;  // Diffuse intensity (%)
int specular  =   0;  // Specular intensity (%)
int shininess =   0;  // Shininess (power of two)
float shiny   =   1;  // Shininess (value)
int zh        =  90;  // Light azimuth
float ylight  =   0;  // Elevation of light
typedef struct {float x,y,z;} vtx;
typedef struct {int A,B,C;} tri;
#define n 500
vtx is[n];

/*
 *  Draw vertex in polar coordinates with normal
 *  Taken from class example 13
 */
static void Vertex(double th,double ph)
{
   double x = Sin(th)*Cos(ph);
   double y = Cos(th)*Cos(ph);
   double z =         Sin(ph);
   //  For a sphere at the origin, the position
   //  and normal vectors are the same
   glNormal3d(x,y,z);
   glVertex3d(x,y,z);
}

/*
 *  Draw a ball
 *     at (x,y,z)
 *     radius (r)
 *  Taken from class example 13
 */
static void ball(double x,double y,double z,double r)
{ 
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glScaled(r,r,r);
   //  White ball with yellow specular
   float yellow[]   = {1.0,1.0,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,yellow);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);
   //  Bands of latitude
   for (int ph=-90;ph<90;ph+=inc)
   {
      glBegin(GL_QUAD_STRIP);
      for (int th=0;th<=360;th+=2*inc)
      {
         Vertex(th,ph);
         Vertex(th,ph+inc);
      }
      glEnd();
   }
   //  Undo transofrmations
   glPopMatrix();
}

// Taken from class example 18
static void BallVertex(int th,int ph)
{
   double x = Cos(th)*Cos(ph);
   double y = Sin(th)*Cos(ph);
   double z =         Sin(ph);
   glNormal3d(x,y,z);
   glTexCoord2d(th/120.0,ph/60.0+0.5);
   glVertex3d(x,y,z);
}

/*
 *  Draw a ball
 *     at (x,y,z)
 *     radius (r)
 *  Taken from class example 13
 */
static void Texball(double x,double y,double z,double dx, double dy, double dz, int tex)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glScaled(dx,dy,dz);
   //  White ball with yellow specular
   float yellow[]   = {1.0,1.0,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,yellow);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[tex]);
   //  Bands of latitude
   for (int ph=-90;ph<90;ph+=inc)
   {
      glBegin(GL_QUAD_STRIP);
      for (int th=0;th<=360;th+=2*inc)
      {
         BallVertex(th,ph);
         BallVertex(th,ph+inc);
      }
      glEnd();
   }
   glDisable(GL_TEXTURE_2D);
   //  Undo transofrmations
   glPopMatrix();
}




/* 
 *  Draw sky box
 */
static void Sky(double D)
{
   //  Textured white box dimension (-D,+D)
   glPushMatrix();
   glScaled(D,D,D);
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   glColor3f(1,1,1);

   //  Sides
   switch (view) // Binds textures skybox for different scenes
   {
   case 0: // Graveyard Scene
      glBindTexture(GL_TEXTURE_2D,skyTex[0]);
      break;
   case 1: // Fishtank Scene
      glBindTexture(GL_TEXTURE_2D,waterTex[0]);
      break;
   case 2: // Desert Scene
      glBindTexture(GL_TEXTURE_2D,pyramidTex[1]);
      break;
   case 3: // Forest Scene
      glBindTexture(GL_TEXTURE_2D,skyTex[0]);
      break;
   
   default:
      break;
   }

   // Sides of sky box
   glBegin(GL_QUADS);
   glTexCoord2f(0.00,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(0.25,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(0.25,1); glVertex3f(+1,+1,-1);
   glTexCoord2f(0.00,1); glVertex3f(-1,+1,-1);

   glTexCoord2f(0.25,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(0.50,0); glVertex3f(+1,-1,+1);
   glTexCoord2f(0.50,1); glVertex3f(+1,+1,+1);
   glTexCoord2f(0.25,1); glVertex3f(+1,+1,-1);

   glTexCoord2f(0.50,0); glVertex3f(+1,-1,+1);
   glTexCoord2f(0.75,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(0.75,1); glVertex3f(-1,+1,+1);
   glTexCoord2f(0.50,1); glVertex3f(+1,+1,+1);

   glTexCoord2f(0.75,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(1.00,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(1.00,1); glVertex3f(-1,+1,-1);
   glTexCoord2f(0.75,1); glVertex3f(-1,+1,+1);
   glEnd();

   switch (view) // Binds texture for top of skybox
   {
   case 0: // Graveyard scene
      glBindTexture(GL_TEXTURE_2D,skyTex[1]);
      break;
   case 1: // Fishtank Scene
      glBindTexture(GL_TEXTURE_2D,waterTex[0]);
      break;
   case 2: // Desert Scene
      glBindTexture(GL_TEXTURE_2D,skyTex[1]);
      break;
   case 3:
      glBindTexture(GL_TEXTURE_2D,skyTex[1]);
      break;
   default:
      break;
   }
   glBegin(GL_QUADS); // Top of sky box
   glTexCoord2f(0.0,0); glVertex3f(+1,+1,-1);
   glTexCoord2f(0.5,0); glVertex3f(+1,+1,+1);
   glTexCoord2f(0.5,1); glVertex3f(-1,+1,+1);
   glTexCoord2f(0.0,1); glVertex3f(-1,+1,-1);
   glEnd();

   switch (view) // Binds textures for bottom of sky box
   {
   case 0: // Graveyard scene
      glBindTexture(GL_TEXTURE_2D,skyTex[1]);
      break;
   case 1: // Fishtank Scene
      glBindTexture(GL_TEXTURE_2D,waterTex[2]);
      break;
   case 2: // Desert Scene
      glBindTexture(GL_TEXTURE_2D,pyramidTex[2]);
      break;
   case 3: // Forest Scene
      glBindTexture(GL_TEXTURE_2D,texture[2]);
      break;
   default:
      break;
   }

   glBegin(GL_QUADS); // Bottom of skybox
   glTexCoord2f(1.0,1); glVertex3f(-1,-1,+1);
   glTexCoord2f(0.5,1); glVertex3f(+1,-1,+1);
   glTexCoord2f(0.5,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(1.0,0); glVertex3f(-1,-1,-1);
   glEnd();

   //  Undo
   glDisable(GL_TEXTURE_2D);
   glPopMatrix();
}

/*
 * Draw little cactus
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 */
static void littleCactus (double x, double y, double z, double dx, double dy, double dz)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glScaled(dx,dy,dz);
   //  White ball with yellow specular
   float yellow[]   = {1.0,1.0,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,yellow);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   // Enable textures
   glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,cactusTex[0]);//Binds cactus texture
   //  Bands of latitude
   for (int ph=-90;ph<90;ph+=inc)
   {
      glBegin(GL_QUAD_STRIP);
      for (int th=0;th<=360;th+=2*inc)
      {
         BallVertex(th,ph);
         BallVertex(th,ph+inc);
      }
      glEnd();
   }
   glDisable(GL_TEXTURE_2D);
   //  Undo transofrmations
   glPopMatrix();
}

/*
 * Draws larger cactus
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated around the y axis by th
 */
static void largeCactus(double x, double y, double z, double dx, double dy, double dz, double th)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glScaled(dx,dy,dz);
   //  White ball with yellow specular
   float yellow[]   = {1.0,1.0,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,yellow);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   // Enables Textures
   glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,cactusTex[0]); // Binds cactus texture
   //  Bands of latitude
  

   // First - Main stem (cylinder) and cap to main stem (sphere)

   glColor3f(1,1,1);
      double index = 0;
      double cone = 1;
      double tail = 0;
      double wid = 1;
      glBegin(GL_QUADS); // Creates cyclinder for cactus body
         for (int th=0;th<=360;th+=10)
         {
            
            glNormal3f(wid*Cos(th),0,wid*Sin(th));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
            index++;
            glNormal3f(wid*Cos(th+10),0,wid*Sin(th+10));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th+10),tail,wid*Sin(th+10));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th+10),cone,wid*Sin(th+10));
         }
         glEnd();

         littleCactus(0,cone,0,1,1,1); // Creates round top to the cactus
      
      



   // Secondary - Arms of cactus consisting of two cylinders and a sphere to round the connection


   // I want to add arms to this larger cactus




   
   glDisable(GL_TEXTURE_2D);
   //  Undo transofrmations
   glPopMatrix();
}

/*
 * Draw Ghost
 * at (x,y,z)
 * with (dx,dy,dz) scaler
 * Based on code from class example 13
 */
static void ghost(double x, double y, double z, double r, double th)
   {
      //  Save transformation
      glPushMatrix();
      //  Offset, scale and rotate
      glTranslated(x,y,z);
      glRotated(th,0,1,0);
      glScaled(r,r,r);

      //  White ball with yellow specular
      // From example 13
      float yellow[]   = {1.0,1.0,0.0,1.0};
      float Emission[] = {0.0,0.0,0.01*emission,1.0};
      glColor3f(1,1,1);
      glMaterialf(GL_FRONT,GL_SHININESS,shiny);
      glMaterialfv(GL_FRONT,GL_SPECULAR,yellow);
      glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

      const double cone = 3;
      const double tail = 1;
      const  double wid = 1;


      // Cone

      // Bottom
      glColor3f(1,1,1);
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[1]); // textured the ghost with a sheet to be like a bed sheet
      glBegin(GL_TRIANGLE_FAN);
         glNormal3f(0,-1,0);
         glTexCoord2f(.5,.5); glVertex3f(0,tail,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(wid*Cos(th),wid*Sin(th)); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
         }
         glEnd();
      glDisable(GL_TEXTURE_2D);

      // Side
      // Based on function from class example 8
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[1]); // textured the body with a cloth texture to be like a bedsheet
      glBegin(GL_TRIANGLES);
         for (int th=0;th<=360;th+=10)
         {
            glNormal3f(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(Cos(th),Sin(th)); glVertex3f(wid*Cos(th),tail,wid*Sin(th));
            glNormal3f(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(.5,.5); glVertex3d(0,cone,0);
            glNormal3f(wid*Cos(th + 10),cone,wid*Sin(th + 10));
            glTexCoord2f(Cos(th + 10),Sin(th + 10)); glVertex3d(wid*Cos(th + 10),tail,wid*Sin(th +10));
         }
         glEnd();
      //  Switch off textures so it doesn't apply to the rest
      glDisable(GL_TEXTURE_2D);
      
      // Head
      //  Bands of latitude
      glColor3f(1,1,1);
      Texball(0,3,0,.5,.5,.5,1); // textured with cloth to show the ghost is wearing the traditional bedsheet

      // Eyes
      glColor3f(0,0,0);
      ball(.5,3.1,.1, .1); // did not texture the black eyeballs as the eyes are meant to be comical and simplistic
      ball(.5,3.1,-.1,.1); // Also difficult to texture the black eyes and make it look good

      const double hat = 1;

      // Hat 
      glColor3f(1,1,1);
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[8]); // creates stripes in the argyle colors with the texture
      glBegin(GL_POLYGON); // textured in argyle
         glNormal3f(0,1,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(.5 + .5* Cos(th),.5 + .5* Sin(th)); glVertex3d(hat*Cos(th),tail + 2.4,hat*Sin(th));
         }
         glEnd();
      glDisable(GL_TEXTURE_2D);

      // Hat 
      glColor3f(1,1,1);
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[8]); // creates stripes in the argyle colors with the texture
      glBegin(GL_POLYGON); // textured in argyle
         glNormal3f(0,-1,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(.5 + .5* Cos(th),.5 + .5* Sin(th)); glVertex3d(hat*Cos(th),tail + 2.2,hat*Sin(th));
         }
         glEnd();
      glDisable(GL_TEXTURE_2D);

      // Hat sides
      const double t = 3.4;
      const double b = 3.2;
      const double w = 1;
      glColor3f(1,1,1);
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[8]); // creates stripes in the argyle colors with the texture
      glBegin(GL_QUADS);
         for (int th=0;th<=360;th+=10)
         {
            glNormal3f(w*Cos(th),0,w*Sin(th));
            glTexCoord2f(0,1); glVertex3d(w*Cos(th),t,w*Sin(th));
            glTexCoord2f(0,0); glVertex3d(w*Cos(th),b,w*Sin(th));
            glNormal3f(w*Cos(th + 10),0,w*Sin(th + 10));
            glTexCoord2f(0,0); glVertex3d(w*Cos(th + 10),b,w*Sin(th + 10));
            glTexCoord2f(0,1); glVertex3d(w*Cos(th + 10),t,w*Sin(th + 10));
         }
         glEnd();
      glDisable(GL_TEXTURE_2D);

      // Hat sides
      const double top = 4.4;
      const double bottom = 3.4;
      const double width = .5;
      glColor3f(1,1,1);
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[8]); // creates stripes in the argyle colors with the texture
      double index = 0;
      glBegin(GL_QUADS);
         for (int th=0;th<=360;th+=10)
         {
            glNormal3f(width*Cos(th),0,width*Sin(th));
            glTexCoord2f(index/36,1); glVertex3d(width*Cos(th),top,width*Sin(th));
            glTexCoord2f(index/36,0); glVertex3d(width*Cos(th),bottom,width*Sin(th));
            index++;
            glNormal3f(width*Cos(th + 10),0,width*Sin(th + 10));
            glTexCoord2f(index/36,0); glVertex3d(width*Cos(th + 10),bottom,width*Sin(th + 10));
            glTexCoord2f(index/36,1); glVertex3d(width*Cos(th + 10),top,width*Sin(th + 10));
         }
         glEnd();
      glDisable(GL_TEXTURE_2D);

      // Hat top
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[8]);
      glColor3f(1,1,1);
      glBegin(GL_POLYGON); // textured with argile 
         glNormal3f(0,1,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(.5 + .5*Cos(th),.5 + .5*Sin(th)); glVertex3d(width*Cos(th),top,width*Sin(th));
         }
         glEnd();
      glDisable(GL_TEXTURE_2D);
   
      //  Undo transofrmations
      glPopMatrix();
   }

/*
 * Draw a Headstone
 *  at (x,y,z)
 *  with (dx,dy,dz) scaler
 *  with (th) rotation in degrees
 */

static void gravestone(double x,double y,double z,double dx,double dy,double dz,double th)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glRotated(th,0,1,0);
   glScaled(dx,dy,dz);
   
   //  gray box with gray specular
   float gray[]   = {0.1,0.1,0.1,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glColor3f(1,1,1);
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,gray);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   glBindTexture(GL_TEXTURE_2D,texture[7]); // texture meant to look like a marble headstone

   glBegin(GL_QUADS);
   // Front
   glColor3f(1,1,1);
   glNormal3f(0,0,1);
   glTexCoord2f(0,0); glVertex3f(-.25,0,1);
   glTexCoord2f(0,1); glVertex3f(-.25,1,1);
   glTexCoord2f(1,1);glVertex3f(.25,1,1);
   glTexCoord2f(1,0); glVertex3f(.25,0,1);

   // Back
   glNormal3f(0,0,-1);
   glTexCoord2f(0,0); glVertex3f(-.25,0,-1);
   glTexCoord2f(0,1); glVertex3f(-.25,1,-1);
   glTexCoord2f(1,1); glVertex3f(.25,1,-1);
   glTexCoord2f(1,0); glVertex3f(.25,0,-1);

   // Sides
   glNormal3f(1,0,0);
   glTexCoord2f(0,0); glVertex3f(.25,0,-1);
   glTexCoord2f(0,.5);glVertex3f(.25,0,1);
   glTexCoord2f(.5,.5);glVertex3f(.25,1,1);
   glTexCoord2f(.5,0); glVertex3f(.25,1,-1);

   glNormal3f(-1,0,0);
   glTexCoord2f(0,0); glVertex3f(-.25,0,-1);
   glTexCoord2f(0,.5); glVertex3f(-.25,0,1);
   glTexCoord2f(.5,.5); glVertex3f(-.25,1,1);
   glTexCoord2f(.5,0); glVertex3f(-.25,1,-1);

   // Top (TEMP)

   glNormal3f(0,1,0);
   glTexCoord2f(0,0); glVertex3f(-.25,1,-1);
   glTexCoord2f(0,.5);glVertex3f(-.25,1,1);
   glTexCoord2f(.5,.5); glVertex3f(.25,1,1);
   glTexCoord2f(.5,0); glVertex3f(.25,1,-1);

   glEnd();

    //  Switch off textures so it doesn't apply to the rest
      glDisable(GL_TEXTURE_2D);

   //  Undo transofrmations
   glPopMatrix();

}

/* 
 * Draw a Tree
 * as (x,y,z)
 * scaled by (dx,dy,dz)
 * Based on code from class example 8
 */

static void tree(double x, double y, double z, double dx, double dy, double dz)
   {
      //  Save transformation
      glPushMatrix();
      //  Offset, scale and rotate
      glTranslated(x,y,z);
      glScaled(dx,dy,dz);

      //  gray box with gray specular
      float gray[]   = {0.1,0.1,0.1,1.0};
      float Emission[] = {0.0,0.0,0.01*emission,1.0};
      glColor3f(1,1,1);
      glMaterialf(GL_FRONT,GL_SHININESS,shiny);
      glMaterialfv(GL_FRONT,GL_SPECULAR,gray);
      glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

      const double cone = 2;
      const double tail = 0;
      const  double wid = 1;
      const double leave = 2;

      // Trunk 
      // Based on code from class example 8
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[0]); // bark of the tree
      glColor3f(1,1,1);
      double index = 0;
      glBegin(GL_QUADS);
         for (int th=0;th<=360;th+=10)
         {
            
            glNormal3f(wid*Cos(th),0,wid*Sin(th));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
            index++;
            glNormal3f(wid*Cos(th+10),0,wid*Sin(th+10));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th+10),tail,wid*Sin(th+10));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th+10),cone,wid*Sin(th+10));
         }
         glEnd();
      //  Switch off textures so it doesn't apply to the rest
      glDisable(GL_TEXTURE_2D);

      // Leaves
      glColor3f(0,.8,0);

        glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[3]); // needles of the tree

      glBegin(GL_TRIANGLES);
         for (int th=0;th<=360;th+=10)
         {
            glNormal3f(leave*Cos(th),cone + 2,leave*Sin(th));
            glTexCoord2f(.5*Cos(th),.5*Sin(th)); glVertex3f(leave*Cos(th),tail + 2,leave*Sin(th));
            glNormal3f(leave*Cos(th),cone + 2,leave*Sin(th));
            glTexCoord2f(0,0); glVertex3d(0,cone + 2,0);
            glNormal3f(leave*Cos(th+ 10),cone + 2,leave*Sin(th+ 10));
            glTexCoord2f(.5*Cos(th +10),.5*Sin(th + 10)); glVertex3d(leave*Cos(th + 10),tail + 2,leave*Sin(th +10));
         }
         glEnd();
      

      
      glBegin(GL_TRIANGLE_FAN); //  Bottom of the leaves
         glNormal3f(0,-1,0);
         glVertex3f(0,tail + 2,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(Cos(th),Sin(th)); glVertex3d(leave*Cos(th),tail + 2,leave*Sin(th));
         }
         glEnd();
   
    glDisable(GL_TEXTURE_2D);

      //  Undo transofrmations
      glPopMatrix();
      
   }
/*
 * draws coconut
 * at (x,y,z)
 * scaled by (r,r,r)
 */
static void coconut(double x, double y, double z, double r)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glScaled(r,r,r);

   // Enables textures
   glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,palmTex[1]); // Binds coconut texture
   //  Bands of latitude
   for (int ph=-90;ph<90;ph+=inc)
   {
      glBegin(GL_QUAD_STRIP);
      for (int th=0;th<=360;th+=2*inc)
      {
         BallVertex(th,ph);
         BallVertex(th,ph+inc);
      }
      glEnd();
   }
   glDisable(GL_TEXTURE_2D);
   //  Undo transofrmations
   glPopMatrix();
}

/* 
 * draws palm tree
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated around the y axis by th
 */
static void palmTree(double x, double y, double z, double dx, double dy, double dz, double th)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glRotated(th,0,1,0);
   glScaled(dx,dy,dz);

   const double cone = 2;
      const double tail = 0;
      const  double wid = 1;
      // const double leave = 2;

      // Trunk 
      // Based on code from class example 8
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[0]); // bark of the tree
      glColor3f(1,1,1);
      double index = 0;
      glBegin(GL_QUADS); // Trunk of palm tree
         for (int th=0;th<=360;th+=10)
         {
            
            glNormal3f(wid*Cos(th),0,wid*Sin(th));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
            index++;
            glNormal3f(wid*Cos(th+10),0,wid*Sin(th+10));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th+10),tail,wid*Sin(th+10));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th+10),cone,wid*Sin(th+10));
         }
         glEnd();

         // Add Leaves to tree

         // Add coconuts to tree


      //  Switch off textures so it doesn't apply to the rest
      glDisable(GL_TEXTURE_2D);

   glPopMatrix();

}

/*
 * draws a log
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated by th around the x axis, ph around the z axis, and yh around the y axis
 */
static void wood(double x, double y, double z, double dx, double dy, double dz, double th, double ph, double yh)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glRotated(th,1,0,0);
   glRotated(ph,0,0,1);
   glRotated(yh,0,1,0);
   glScaled(dx,dy,dz);

   // Trunk 
      // Based on code from class example 8
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[0]); // bark of the tree
      glColor3f(1,1,1);

      const double cone = 1;
      const double tail = -1;
      const  double wid = .5;
      double index = 0;
      glBegin(GL_QUADS); // Trunk of log
         for (int th=0;th<=360;th+=10)
         {
            
            glNormal3f(wid*Cos(th),0,wid*Sin(th));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
            index++;
            glNormal3f(wid*Cos(th+10),0,wid*Sin(th+10));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th+10),tail,wid*Sin(th+10));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th+10),cone,wid*Sin(th+10));
         }
         glEnd();

         glBindTexture(GL_TEXTURE_2D,treeTex[0]); // end of the log

         //Top
         glBegin(GL_POLYGON); // end of log
         glNormal3f(0,1,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(.5 + .5* Cos(th),.5 + .5* Sin(th)); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
         }
         glEnd();

         //Bottom
         glBegin(GL_POLYGON); // other end of log
         glNormal3f(0,-1,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(.5 + .5* Cos(th),.5 + .5* Sin(th)); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
         }
         glEnd();


      //  Switch off textures so it doesn't apply to the rest
      glDisable(GL_TEXTURE_2D);

      glPopMatrix();
}

/*
 * draws dead tree
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated by th around the y axis
 */
static void deadTree(double x, double y, double z, double dx, double dy, double dz, double th)
{
   //  Save transformation
   glPushMatrix();
   //  Offset, scale and rotate
   glTranslated(x,y,z);
   glRotated(th,1,0,0);
   glScaled(dx,dy,dz);

   // Draws logs to form dead tree
   wood(0,2,0,1,2,1,0,0,0);
   wood(1,4.5,0,1,1.5,1,0,135,0);
   wood(-1,4.5,0,1,1.5,1,0,225,0);

   glPopMatrix();
}


/* 
 * Draw a lightpost
 * at (x,y,z)
 */
static void lightpost(double x, double y, double z, double dx, double dy, double dz)
   {
      //  Save transformation
      glPushMatrix();
      //  Offset, scale and rotate
      glTranslated(x,y,z);
      glScaled(dx,dy,dz);

      //  gray box with gray specular
      float gray[]   = {0.1,0.1,0.1,1.0};
      float Emission[] = {0.0,0.0,0.01*emission,1.0};
      glColor3f(1,1,1);
      glMaterialf(GL_FRONT,GL_SHININESS,shiny);
      glMaterialfv(GL_FRONT,GL_SPECULAR,gray);
      glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

      //Post
      const double cone = 1;
      const double tail = 0;
      const  double wid = .2;

      glColor3f(1,1,1);

      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,texture[5]); // textured metal post for the light
      double index = 0;
      glBegin(GL_QUADS);
         for (int th=0;th<=360;th+=10)
         {
            glNormal3f(wid*Cos(th),0,wid*Sin(th));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
            index++;
            glNormal3f(wid*Cos(th+10),0,wid*Sin(th+10));
            glTexCoord2f(index/36,0); glVertex3d(wid*Cos(th+10),tail,wid*Sin(th+10));
            glTexCoord2f(index/36,1); glVertex3d(wid*Cos(th+10),cone,wid*Sin(th+10));
         }
         glEnd();

      glDisable(GL_TEXTURE_2D);

      // Undo transformations
      glPopMatrix();
   }

/*
 * draws a fish
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated by th around the y axis
 */
static void fish(double x, double y, double z, double dx, double dy, double dz, double th)
{
    //  Save transformation
      glPushMatrix();
      //  Offset, scale and rotate
      glTranslated(x,y,z);
      glScaled(dx,dy,dz);
      // glRotated(th,0,1,0); // Going to rotate fish to swim in a circle

      //  gray box with gray specular
      float gray[]   = {0.1,0.1,0.1,1.0};
      float Emission[] = {0.0,0.0,0.01*emission,1.0};
      glColor3f(1,1,1);
      glMaterialf(GL_FRONT,GL_SHININESS,shiny);
      glMaterialfv(GL_FRONT,GL_SPECULAR,gray);
      glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

      //Post
      const double cone = 1;
      const double tail = 0;
      const  double wid = .2;

      glColor4f(1,0,0,alpha); // red fish

      // Enables textures
      glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,waterTex[1]); // binds scale texture
      double index = 0;

          glBegin(GL_QUADS); // Body of fish
         for (int th=0;th<=360;th+=10)
         {
            glNormal3f(0,wid*Cos(th),wid*Sin(th));
            glTexCoord2f(index/36,1); glVertex3d(cone,wid*Cos(th),wid*Sin(th));
            glTexCoord2f(index/36,0); glVertex3d(tail,wid*Cos(th),wid*Sin(th));
            index++;
            glNormal3f(0,wid*Cos(th+10),wid*Sin(th+10));
            glTexCoord2f(index/36,0); glVertex3d(tail,wid*Cos(th+10),wid*Sin(th+10));
            glTexCoord2f(index/36,1); glVertex3d(cone,wid*Cos(th+10),wid*Sin(th+10));
         }
         glEnd();

            // Top
               glBegin(GL_POLYGON); // Front of the fish body
               glNormal3f(1,0,0);
                     for (int th=0;th<=360;th+=10)
                     {
                        glTexCoord2f(.5 + .5*Cos(th),.5 + .5*Sin(th)); glVertex3d(cone,wid*Cos(th),wid*Sin(th));
                     }
               glEnd();

               // bottom 
               glBegin(GL_POLYGON); // back of the fish body
               glNormal3f(-1,0,0);
                     for (int th=0;th<=360;th+=10)
                     {
                        glTexCoord2f(.5 + .5*Cos(th),.5 + .5*Sin(th)); glVertex3d(tail,wid*Cos(th),wid*Sin(th));
                     }
               glEnd();

            // Head
               double head = 1.2;
               double headWid = 0.1;
             glBegin(GL_QUADS); // cone of the fish head
               for (int th=0;th<=360;th+=10)
               {
                  glNormal3f(head-cone,wid*Cos(th),wid*Sin(th));
                  glTexCoord2f(index/72,1); glVertex3d(head,headWid*Cos(th),headWid*Sin(th));
                  glTexCoord2f(index/72,0); glVertex3d(cone,wid*Cos(th),wid*Sin(th));
                  index++;
                  glNormal3f(cone,wid*Cos(th + 10),wid*Sin(th + 10));
                  glTexCoord2f(index/72,0); glVertex3d(cone,wid*Cos(th+10),wid*Sin(th+10));
                  glTexCoord2f(index/72,1); glVertex3d(head,headWid*Cos(th+10),headWid*Sin(th+10));
               }
               glEnd();

            // Nose
            // Top
               glBegin(GL_POLYGON); // fish nose
               glNormal3f(1,0,0);
                     for (int th=0;th<=360;th+=10)
                     {
                        glTexCoord2f(.5 + .5*Cos(th),.5 + .5*Sin(th)); glVertex3d(head,headWid*Cos(th),headWid*Sin(th));
                     }
               glEnd();

            //fins
            glBegin(GL_TRIANGLES);
            glNormal3f(0,0,1);
            glTexCoord2f(0,1); glVertex3d(cone-.3,wid+.1,0);
            glTexCoord2f(1,1); glVertex3d(tail+.3,wid+.1,0);
            glTexCoord2f(0,.5); glVertex3d(cone/2,wid-.2,0);
            glEnd();


      glDisable(GL_TEXTURE_2D);

      glColor3f(0,0,0); // Fish eyes
      ball(1.1,.11,.11,.03);
      ball(1.1,.11,-.11,.03);

      // Undo transformations
      glPopMatrix();
}

/*
 * draws potted plant
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * roated round y axis by th
 */
static void pottedPlant( double x, double y, double z, double dx, double dy, double dz, double th)
{
   //  Save transformation
      glPushMatrix();
      //  Offset, scale and rotate
      glTranslated(x,y,z);
      glScaled(dx,dy,dz);

      // Pot

      // plant

      glPopMatrix();
}

/*
 * draws kelp
 * at (x,y,z)
 * scaled by (dx,dy,dx)
 */
static void kelp(double x, double y, double z, double dx, double dy, double dz)
{
   //  Save transformation
      glPushMatrix();
      //  Offset, scale and rotate
      glTranslated(x,y,z);
      glScaled(dx,dy,dz);

      

      double wid = 1;
      double cone = 1;
      double tail = 0;


      glColor3f(.2,.9,.2);

      while (cone < 5) // draws 4 cylinders that will shift by a sin wave
      {
         double index = 0;

         if (cone == 1) // first cylinder does not move
         {
            glBegin(GL_QUADS);
            for (int th=0;th<=360;th+=10)
            {
               glNormal3f(wid*Cos(th),0,wid*Sin(th));
               glVertex3d(wid*Cos(th),cone,wid*Sin(th));
               glVertex3d(wid*Cos(th),tail,wid*Sin(th));
               index++;
               glNormal3f(wid*Cos(th+10),0,wid*Sin(th+10));
               glVertex3d(wid*Cos(th+10),tail,wid*Sin(th+10));
               glVertex3d(wid*Cos(th+10),cone,wid*Sin(th+10));
            }
         glEnd();
         }
         else{
            glBegin(GL_QUADS); // each cylinder is dislaced by a sin factor
            for (int th=0;th<=360;th+=10)
            {
               glNormal3f(wid*Cos(th),0,wid*Sin(th));
               glVertex3d(wid*Cos(th) + Sin(cone/2),cone,wid*Sin(th));
               glVertex3d(wid*Cos(th) + Sin(cone/2),tail,wid*Sin(th));
               index++;
               glNormal3f(wid*Cos(th+10),0,wid*Sin(th+10));
               glVertex3d(wid*Cos(th+10) + Sin(cone/2),tail,wid*Sin(th+10));
               glVertex3d(wid*Cos(th+10) + Sin(cone/2),cone,wid*Sin(th+10));
            }
         glEnd();
         }
         cone += 1;
         tail += 1;
         Kth += .5;
      }

   glPopMatrix();
}

/* 
 * draws water that is translucent to see fish below
 */
static void water()
{
   //  Save transformation
      glPushMatrix();

      fish(0,0,0,2,2,2,0); // draws a fish under the water


      // enable blending to allow tranlucent water
    glEnable(GL_BLEND);



      glDepthMask(GL_FALSE); // does not write over the z buffer
      glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

              glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,waterTex[0]); 
      
      glColor4f(1,1,1, .5);
      glNormal3f(0,1,0);
      glBegin(GL_QUADS);
      glTexCoord2f(0,0); glVertex3f(-9,3,-9);
      glTexCoord2f(0,9); glVertex3f(-9,3,9);
      glTexCoord2f(9,9); glVertex3f(9,3,9);
      glTexCoord2f(9,0); glVertex3f(9,3,-9);
      glEnd();

      glDepthMask(GL_TRUE); // pixels will be written to z buffer

      glDisable(GL_BLEND); // turns off blending



      glPopMatrix();
}

/*
 * draws pyramid
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 */
static void pyramid(double x, double y, double z, double dx, double dy, double dz, double height)
{
   //  Save transformation
      glPushMatrix();
      //  Offset, scale and rotate
      glTranslated(x,y,z);
      glScaled(dx,dy,dz);

      glColor3f(1,1,0);

      //Enables textures
      glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   glBindTexture(GL_TEXTURE_2D,pyramidTex[0]); // binds limestone texture

      glBegin(GL_TRIANGLES); // each face of the pyramid
      glNormal3f(0,1,-.5);
      glTexCoord2f(0,0); glVertex3d(-.5,0,-.5);
      glTexCoord2f(.5,1); glVertex3f(0,1,0);
      glTexCoord2f(1,0); glVertex3f(.5,0,-.5);

      glNormal3f(.5,1,0);
      glTexCoord2f(0,0); glVertex3d(.5,0,-.5);
      glTexCoord2f(.5,1); glVertex3f(0,1,0);
      glTexCoord2f(1,0); glVertex3f(.5,0,.5);

      glNormal3f(0,1,.5);
      glTexCoord2f(0,0); glVertex3d(.5,0,.5);
      glTexCoord2f(.5,1); glVertex3f(0,1,0);
      glTexCoord2f(1,0); glVertex3f(-.5,0,.5);

      glNormal3f(-.5,1,0);
      glTexCoord2f(0,0); glVertex3d(-.5,0,.5);
      glTexCoord2f(.5,1); glVertex3f(0,1,0);
      glTexCoord2f(1,0); glVertex3f(-.5,0,-.5);
      glEnd();

        //  Switch off textures so it doesn't apply to the rest
      glDisable(GL_TEXTURE_2D);


      glPopMatrix();



}

/*
 * Draw the grass ground
 * at (x,y,z)
 * scaled by (r,dy,r)
 * rotated by (th) degrees
 */

static void grass(double x,double y,double z,double r,double dy)
{
   //  Save transformation
   glPushMatrix();
   //  Offset and scale
   glTranslated(x,y,z);
   glScaled(r,dy,r);

   //  White ball with yellow specular
   float darkGreen[]   = {0,0.3,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,darkGreen);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   // Ground

   const double cone = 0;
   const double tail = -1;
   const  double wid = 1;
   glColor3f(1,1,1);

   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   glBindTexture(GL_TEXTURE_2D,texture[2]); // grassy texture to show lush grass

   // Top
   glBegin(GL_POLYGON);
   glNormal3f(0,1,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(.5 + .5*Cos(th),.5 + .5*Sin(th)); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
         }
   glEnd();

   glColor3f(1,1,1);

      // Bottom
         glBegin(GL_POLYGON);
         glNormal3f(0,-1,0);
         for (int th=0;th<=360;th+=10)
         {
            glTexCoord2f(.5 + .5*Cos(th),.5 + .5*Sin(th)); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
         }
         glEnd();

            
         
         // Side
         glBegin(GL_QUADS);
         for (int th=0;th<=360;th+=10)
         {
            glNormal3f(wid*Cos(th),0,wid*Sin(th));
            glTexCoord2f(0,1); glVertex3d(wid*Cos(th),cone,wid*Sin(th));
            glTexCoord2f(0,0); glVertex3d(wid*Cos(th),tail,wid*Sin(th));
            glNormal3f(wid*Cos(th + 10),0,wid*Sin(th + 10));
            glTexCoord2f(1,1); glVertex3d(wid*Cos(th + 10),tail,wid*Sin(th + 10));
            glTexCoord2f(1,0); glVertex3d(wid*Cos(th+ 10),cone,wid*Sin(th+10));
         }
         glEnd();
      
      //  Switch off textures so it doesn't apply to the rest
      glDisable(GL_TEXTURE_2D);

   //  Undo transofrmations
   glPopMatrix();


}

/*
 * draws a fencepost
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated by th around the y axis
 */
static void Fencepost(double x,double y,double z,
                 double dx,double dy,double dz,
                 double th)
{
     //  Save transformation
   glPushMatrix();
   //  Offset
   glTranslated(x,y,z);
   glRotated(th,0,1,0);
   glScaled(dx,dy,dz);

   //  White ball with yellow specular
   float darkGreen[]   = {0,0.3,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,darkGreen);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   // Fencepost
   glColor3f(1,1,1);
   glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,5); // wooden fence posts
    glBegin(GL_QUADS);
   
   // Front
   glNormal3f(0,0,-1);
   glTexCoord2f(0,0); glVertex3d(-.1,0,-.1);
   glTexCoord2f(0,1); glVertex3d(-.1,1,-.1);
   glTexCoord2f(1,1); glVertex3d(.1,1,-.1);
   glTexCoord2f(1,0); glVertex3d(.1,0,-.1);

   // Side
   glNormal3f(1,0,0);
   glTexCoord2f(0,0); glVertex3d(.1,0,-.1);
   glTexCoord2f(0,1); glVertex3d(.1,1,-.1);
   glTexCoord2f(1,1); glVertex3d(.1,1,.1);
   glTexCoord2f(1,0); glVertex3d(.1,0,.1);

   // Back
   glNormal3f(0,0,1);
   glTexCoord2f(0,0); glVertex3d(.1,0,.1);
   glTexCoord2f(0,1); glVertex3d(.1,1,.1);
   glTexCoord2f(1,1); glVertex3d(-.1,1,.1);
   glTexCoord2f(1,0); glVertex3d(-.1,0,.1);

   // Side
   glNormal3f(-1,0,0);
   glTexCoord2f(0,0); glVertex3d(-.1,0,.1);
   glTexCoord2f(0,1); glVertex3d(-.1,1,.1);
   glTexCoord2f(1,1); glVertex3d(-.1,1,-.1);
   glTexCoord2f(1,0); glVertex3d(-.1,0,-.1);

   // Top
   glNormal3f(0,1,0);
   glTexCoord2f(0,0); glVertex3d(-.1,1,-.1);
   glTexCoord2f(0,1); glVertex3d(-.1,1,.1);
   glTexCoord2f(1,1); glVertex3d(.1,1,.1);
   glTexCoord2f(1,0); glVertex3d(.1,1,-.1);
   glEnd();
   glDisable(GL_TEXTURE_2D);



   glPopMatrix();
}

/* draws connection between fencepost
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated by th around the y axis
 */
static void fence(double x,double y,double z,
                 double dx,double dy,double dz,
                 double th)
{
      //  Save transformation
   glPushMatrix();
   //  Offset
   glTranslated(x,y,z);
   glRotated(th,0,1,0);
   glScaled(dx,dy,dz);

   //  White ball with yellow specular
   float darkGreen[]   = {0,0.3,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,darkGreen);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   // Fence connections
   glColor3f(1,1,1);

   glEnable(GL_TEXTURE_2D);
      glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
      glBindTexture(GL_TEXTURE_2D,5); // wooden fence posts

   glBegin(GL_QUADS);

   // Sides
   glNormal3f(0,-1,0);
   glTexCoord2f(0,0); glVertex3d(-.1,-.1,-.5);
   glTexCoord2f(0,1); glVertex3d(-.1,-.1,.5);
   glTexCoord2f(1,1); glVertex3d(.1,-.1,.5);
   glTexCoord2f(1,0); glVertex3d(.1,-.1,-.5);

   glNormal3f(1,0,0);
   glTexCoord2f(0,0); glVertex3d(.1,-.1,-.5);
   glTexCoord2f(0,1); glVertex3d(.1,-.1,.5);
   glTexCoord2f(1,1); glVertex3d(.1,.1,.5);
   glTexCoord2f(1,0); glVertex3d(.1,.1,-.5);

   glNormal3f(0,1,0);
   glTexCoord2f(0,0); glVertex3d(.1,.1,-.5);
   glTexCoord2f(0,1); glVertex3d(.1,.1,.5);
   glTexCoord2f(1,1); glVertex3d(-.1,.1,.5);
   glTexCoord2f(1,0); glVertex3d(-.1,.1,-.5);

   glNormal3f(-1,0,0);
   glTexCoord2f(0,0); glVertex3d(-.1,.1,-.5);
   glTexCoord2f(0,1); glVertex3d(-.1,.1,.5);
   glTexCoord2f(1,1); glVertex3d(-.1,-.1,.5);
   glTexCoord2f(1,0); glVertex3d(-.1,-.1,-.5);
   glEnd();
     glDisable(GL_TEXTURE_2D);

   glPopMatrix();


}

/*
 * draws whole fence
 * at (x,y,z)
 * scaled by (dx,dy,dz)
 * rotated by th around the y axis
 */
static void Fence(double x,double y,double z,
                 double dx,double dy,double dz,
                 double th)
{
       //  Save transformation
   glPushMatrix();
   //  Offset
   glTranslated(x,y,z);
   glRotated(th,0,1,0);
   glScaled(dx,dy,dz);

   //  White ball with yellow specular
   float darkGreen[]   = {0,0.3,0.0,1.0};
   float Emission[] = {0.0,0.0,0.01*emission,1.0};
   glMaterialf(GL_FRONT,GL_SHININESS,shiny);
   glMaterialfv(GL_FRONT,GL_SPECULAR,darkGreen);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);

   // builds fence
   Fencepost(0,0,0,1,1,1,0);
   Fencepost(-1,0,0,1,1,1,0);
   Fencepost(1,0,0,1,1,1,0);
   fence(.5,.6,0,1,1,1,90);
   fence(.5,.3,0,1,1,1,90);
   fence(-.5,.6,0,1,1,1,90);
   fence(-.5,.3,0,1,1,1,90);
   
    glPopMatrix();
}

/*
 *  OpenGL (GLUT) calls this routine to display the scene
 *  Based on clas example 13
 */
void display()
{
   //  Erase the window and the depth buffer
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   //  Enable Z-buffering in OpenGL
   glEnable(GL_DEPTH_TEST);

   //  Undo previous transformations
   glLoadIdentity();
   //  Perspective - set eye position
   if (mode)
   {
      double Ex = -2*dim*Sin(th)*Cos(ph);
      double Ey = +2*dim        *Sin(ph);
      double Ez = +2*dim*Cos(th)*Cos(ph);
      gluLookAt(Ex,Ey,Ez , 0,0,0 , 0,Cos(ph),0);
   }
   //  Orthogonal - set world orientation
   else
   {
      glRotatef(ph,1,0,0);
      glRotatef(th,0,1,0);
   }

   //  Flat or smooth shading
   glShadeModel(smooth ? GL_SMOOTH : GL_FLAT);

   //  Light switch
   if (light)
   {
      //  Translate intensity to color vectors
      float Ambient[]   = {0.01*ambient ,0.01*ambient ,0.01*ambient ,1.0};
      float Diffuse[]   = {0.01*diffuse ,0.01*diffuse ,0.01*diffuse ,1.0};
      float Specular[]  = {0.01*specular,0.01*specular,0.01*specular,1.0};
      //  Light position
      float Position[]  = {distance*Cos(zh),ylight,distance*Sin(zh),1.0};
      //  Draw light position as ball (still no lighting here)
      glColor3f(1,1,1);
      ball(Position[0],Position[1],Position[2] , 0.1);
      Sky(3.5*dim); // draws skybox
      //  OpenGL should normalize normal vectors
      glEnable(GL_NORMALIZE);
      //  Enable lighting
      glEnable(GL_LIGHTING);
      //  Location of viewer for specular calculations
      glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE);
      //  glColor sets ambient and diffuse color materials
      glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
      glEnable(GL_COLOR_MATERIAL);
      //  Enable light 0
      glEnable(GL_LIGHT0);
      //  Set ambient, diffuse, specular components and position of light 0
      glLightfv(GL_LIGHT0,GL_AMBIENT ,Ambient);
      glLightfv(GL_LIGHT0,GL_DIFFUSE ,Diffuse);
      glLightfv(GL_LIGHT0,GL_SPECULAR,Specular);
      glLightfv(GL_LIGHT0,GL_POSITION,Position);
   }
   else
      glDisable(GL_LIGHTING);

   
   // glClearColor(0,0,.4,1);

   switch (view) // switches scene drawn
   {
   case 0: // grave
      //  Draw individual objects
      if (obj==1) 
      ghost(0,0,0,1,0);
      else if (obj==2)
      tree(0,0,0,.5,1,.5);
      else if (obj==3)
      Fence(0,0,0,1,1,1,0);
      else if (obj==4)
         {
            grass(0,0,0,4,.5);
            gravestone(-1.5,0,0,.5,2,.5,0);
         }
      //  Complex scene
      else if (obj==0) // Draws graveyard scene
      {
         ghost(-3,1,0,1,0);

      tree(0,0,3.25,.5,1,.5);
      tree(0,0,-3,.25,2,.25);

      Fence(1.5,0,2.5,1,1,1,0);
      Fence(-1.5,0,-2.5,1,1,1,0);
      Fence(-1.5,0,2.5,1,1,1,0);
      Fence(1.5,0,-2.5,1,1,1,0);
      grass(0,0,0,4,.5);
      gravestone(-1.5,0,0,.5,2,.5,0);
      lightpost(3,0,1,1,3,1);
      lightpost(3,0,-1,1,3,1);
      glColor3f(1,1,1);
      Texball(3,3,1,.35,.35,.35,6); // sun texture fills in for a lightbulb in the lightpost
      Texball(3,3,-1,.35,.35,.35,6);// sun texture fills in for a lightbulb in the lightpost
      }
      
      //  Basic scene
      else if (obj == 5)
      {
             lightpost(0,0,0,1,3,1);
            glColor3f(1,1,1);
            Texball(0,3,0,.35,.35,.35,6);// sun texture fills in for a lightbulb in the lightpost
      }
      break;
   case 1: // fish tank scene

      //       glFogf(GL_FOG_MODE, GL_LINEAR);
      //  double FogCol[3]={0.8f,0.8f,0.8f}; // Define a nice light grey
      // glFogfv(GL_FOG_COLOR,FogCol);     // Set the fog color
      // glFogf(GL_FOG_DENSITY, 5);
      // glEnable(GL_FOG);
      // // glFogfv(GL_FOG_MODE,GL_EXP2);
      //  float FogCol[3]={0.8f,0.8f,0.8f}; // Define a nice light grey
      // glFogfv(GL_FOG_COLOR,FogCol);     // Set the fog color


      water();

      // glDisable(GL_FOG);
      break;

   
   case 2: // draws desert
      littleCactus(0,0,0,1,1.5,1);
      largeCactus(3,0,3,2,2.5,2,0);
      pyramid(5,0,0,2,2,2,1);
      break;
   case 3: // draws forest
      for (int x = 0; x < 5; x++)
      {
         for (int y = 0; y < 5; y++)
         {
            if (treelocation[x][y][2] < .9)
            {
               tree(treelocation[x][y][0] + (5*x),0,treelocation[x][y][1]+(5*y),1,1,1);
            }
            else
            {
               deadTree(treelocation[x][y][0] + (5*x),0,treelocation[x][y][1]+(5*y),1,1,1,0);
            }
         }
      }
      break;

   
   default:
      break;
   }


   //  Switch off textures so it doesn't apply to the rest
   glDisable(GL_TEXTURE_2D);

   //  Draw axes - no lighting from here on
   glDisable(GL_LIGHTING);
   glColor3f(1,1,1);
   if (axes)
   {
      const double len=2.0;  //  Length of axes
      glBegin(GL_LINES);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(len,0.0,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,len,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,0.0,len);
      glEnd();
      //  Label axes
      glRasterPos3d(len,0.0,0.0);
      Print("X");
      glRasterPos3d(0.0,len,0.0);
      Print("Y");
      glRasterPos3d(0.0,0.0,len);
      Print("Z");
   }

   //  Display parameters
   glWindowPos2i(5,5);
   Print("Angle=%d,%d  Dim=%.1f FOV=%d Projection=%s Light=%s",
     th,ph,dim,fov,mode?"Perpective":"Orthogonal",light?"On":"Off");
   if (light)
   {
      glWindowPos2i(5,45);
      Print("Model=%s LocalViewer=%s Distance=%d Elevation=%.1f",smooth?"Smooth":"Flat",local?"On":"Off",distance,ylight);
      glWindowPos2i(5,25);
      Print("Ambient=%d  Diffuse=%d Specular=%d Emission=%d Shininess=%.0f",ambient,diffuse,specular,emission,shiny);
   }

   //  Render the scene and make it visible
   ErrCheck("display");
   glFlush();
   glutSwapBuffers();
}

/*
 *  GLUT calls this routine when the window is resized
 *  Taken from class example 13
 */
void idle()
{
   //  Elapsed time in seconds
   double t = glutGet(GLUT_ELAPSED_TIME)/1000.0;
   zh = fmod(90*t,360.0);
   //  Tell GLUT it is necessary to redisplay the scene
   glutPostRedisplay();
}

/*
 * randomizes placement of trees in plots of 5x5
 */
static void randTree()
{
   for (int i = 0; i < 5; i++)
   {
      for (int j = 0; j < 5; j++)
      {
         int x = rand();
         int y = rand();
         double z = ((double)rand()) / (double)RAND_MAX;
         treelocation[i][j][0] = x%5;
         treelocation[i][j][1] = y%5;
         treelocation[i][j][2] = z;

      }
   }
   glutPostRedisplay();
}

/*
 *  GLUT calls this routine when an arrow key is pressed
 *  Taken from class example 13
 */
void special(int key,int x,int y)
{
   //  Right arrow key - increase angle by 5 degrees
   if (key == GLUT_KEY_RIGHT)
      th += 5;
   //  Left arrow key - decrease angle by 5 degrees
   else if (key == GLUT_KEY_LEFT)
      th -= 5;
   //  Up arrow key - increase elevation by 5 degrees
   else if (key == GLUT_KEY_UP)
      ph += 5;
   //  Down arrow key - decrease elevation by 5 degrees
   else if (key == GLUT_KEY_DOWN)
      ph -= 5;
   //  PageUp key - increase dim
   else if (key == GLUT_KEY_PAGE_DOWN)
      dim += 0.1;
   //  PageDown key - decrease dim
   else if (key == GLUT_KEY_PAGE_UP && dim>1)
      dim -= 0.1;
   //  Smooth color model
   else if (key == GLUT_KEY_F1)
      smooth = 1-smooth;
   //  Local Viewer
   else if (key == GLUT_KEY_F2)
      local = 1-local;
   else if (key == GLUT_KEY_F3)
      distance = (distance==1) ? 5 : 1;
   else if (key == GLUT_KEY_F4) // view for 1st scene
   {
      th = 270;
      ph = 25;
      fov = 45;

      glutPostRedisplay();
   }
   else if (key == GLUT_KEY_F5) // scene 2 view
   {
      th = 0;
      ph = 90;
      view = 1;
      fov = 45;
      glutPostRedisplay();
   }
   else if (key == GLUT_KEY_F6) // scene 3 view
   {
      th = 135;
      ph = 25;
      fov = 45;
      view = 2;
      glutPostRedisplay();
   }
   else if (key == GLUT_KEY_F7) // scene 4 view
   {
      th = 135;
      ph = 25;
      fov = 45;
      view = 3;
      glutPostRedisplay();
   }
   //  Toggle ball increment
   else if (key == GLUT_KEY_F8)
      inc = (inc==10)?3:10;
   //  Flip sign
   else if (key == GLUT_KEY_F9)
      one = -one;
   //  Keep angles to +/-360 degrees
   th %= 360;
   ph %= 360;
   //  Update projection
   Project(mode?fov:0,asp,dim);
   //  Tell GLUT it is necessary to redisplay the scene
   glutPostRedisplay();
}

/*
 *  GLUT calls this routine when a key is pressed
 *  Taken from class example 13
 */
void key(unsigned char ch,int x,int y)
{
   //  Exit on ESC
   if (ch == 27)
      exit(0);
   //  Reset view angle
   else if (ch == '0')
      th = ph = 0;
   //  Toggle axes
   else if (ch == 'x' || ch == 'X')
      axes = 1-axes;
   //  Toggle lighting
   else if (ch == 'l' || ch == 'L')
      light = 1-light;
   //  Switch projection mode
   else if (ch == 'p' || ch == 'P')
      mode = 1-mode;
   //  Toggle light movement
   else if (ch == 'm' || ch == 'M')
      move = 1-move;
   //  Move light
   else if (ch == '<')
      zh += 1;
   else if (ch == '>')
      zh -= 1;
   //  Change field of view angle
   else if (ch == '-' && ch>1)
      fov--;
   else if (ch == '+' && ch<179)
      fov++;
   //  Light elevation
   else if (ch=='[')
      ylight -= 0.1;
   else if (ch==']')
      ylight += 0.1;
   //  Ambient level
   else if (ch=='a' && ambient>0)
      ambient -= 5;
   else if (ch=='A' && ambient<100)
      ambient += 5;
   //  Diffuse level
   else if (ch=='d' && diffuse>0)
      diffuse -= 5;
   else if (ch=='D' && diffuse<100)
      diffuse += 5;
   //  Specular level
   else if (ch=='s' && specular>0)
      specular -= 5;
   else if (ch=='S' && specular<100)
      specular += 5;
   //  Emission level
   else if (ch=='e' && emission>0)
      emission -= 5;
   else if (ch=='E' && emission<100)
      emission += 5;
   //  Shininess level
   else if (ch=='n' && shininess>-1)
      shininess -= 1;
   else if (ch=='N' && shininess<7)
      shininess += 1;
   //  Switch object in scene
   else if (ch == 'o')
      obj = (obj+1)%6;
   else if (ch == 'O')
      obj = (obj+5)%6;
   // Switch scenes
   else if (ch == 'h')
      view += 1;
   else if (ch == 'H')
      view -= 1;
   // Randomize tree placment
   else if (ch == 'r')
      randTree();
   else if (ch == 'R')
      randTree();
   //  Translate shininess power to value (-1 => 0)
   shiny = shininess<0 ? 0 : pow(2.0,shininess);
   //  Reproject
   Project(mode?fov:0,asp,dim);
   //  Tell GLUT it is necessary to redisplay the scene
   glutPostRedisplay();
}

/*
 *  GLUT calls this routine when the window is resized
 *  Taken from clas example 13
 */
void reshape(int width,int height)
{
   //  Ratio of the width to the height of the window
   asp = (height>0) ? (double)width/height : 1;
   //  Set the viewport to the entire window
   glViewport(0,0, RES*width,RES*height);
   //  Set projection
   Project(mode?fov:0,asp,dim);
}





/*
 *  Start up GLUT and tell it what to do
 *  Taken from class example 13
 */
int main(int argc,char* argv[])
{
   //  Initialize GLUT
   glutInit(&argc,argv);
   //  Request double buffered, true color window with Z buffering at 600x600
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutInitWindowSize(400,400);
   glutCreateWindow("Jay-Bentley-Final_Project");
#ifdef USEGLEW
   //  Initialize GLEW
   if (glewInit()!=GLEW_OK) Fatal("Error initializing GLEW\n");
#endif
   //  Set callbacks
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutSpecialFunc(special);
   glutKeyboardFunc(key);
   glutIdleFunc(idle);
   //  Load textures
   texture[0] = LoadTexBMP("bark.bmp");
   texture[1] = LoadTexBMP("cloth.bmp");
   texture[2] = LoadTexBMP("grass.bmp");
   texture[3] = LoadTexBMP("leaves.bmp");
   texture[9] = LoadTexBMP("wood.bmp");
   texture[5] = LoadTexBMP("blackMetal.bmp");
   texture[6] = LoadTexBMP("sun.bmp"); // taken from example 18
   texture[7] = LoadTexBMP("gravestone.bmp");
   texture[8] = LoadTexBMP("argyle.bmp");
   // Load tree texture
   treeTex[0] = LoadTexBMP("logEnd.bmp");
   // Load sky texture
   skyTex[0] = LoadTexBMP("skybox.bmp");
   skyTex[1] = LoadTexBMP("skyboxUP.bmp");
   // Laod cactus texture
   cactusTex[0] = LoadTexBMP("cacTex.bmp");
   // Load water texture
   waterTex[0] = LoadTexBMP("water.bmp");
   waterTex[1] = LoadTexBMP("fishh.bmp");
   waterTex[2] = LoadTexBMP("gravel1.bmp");
   // Load palm tree texture
   palmTex[0] = LoadTexBMP("palmBark.bmp");
   palmTex[1] = LoadTexBMP("coconut.bmp");
   //Load Sandstone textures
   pyramidTex[0] = LoadTexBMP("sandstone.bmp");
   pyramidTex[1] = LoadTexBMP("desertLandscape.bmp");
   pyramidTex[2] = LoadTexBMP("desertGround.bmp");
   //  Pass control to GLUT so it can interact with the user
   ErrCheck("init");
   glutMainLoop();
   return 0;
}
