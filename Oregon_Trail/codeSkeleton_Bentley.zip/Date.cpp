// CSCI 1300 Fall 2020
// Author: Jay Bentley
// Recitation: 210 - Steven Wilmes
// Project 3

#include <iostream>
#include "Date.h"
using namespace std;

Date::Date()
    {
        month = "March";
        monthNumber = 03;
        day = 28;
        year = 1847;
    }

Date::Date(string newMonth, int newMonthNumber, int newDay, int newYear)
    {
        month = newMonth;
        monthNumber = newMonthNumber;
        day = newDay;
        year = newYear;
    }

string Date::getMonth()
    {
        return month;
    }

void Date::setMonth(string newMonth)
    {
        month = newMonth;
    }
    
int Date::getMonthNumber()
    {
        return monthNumber;
    }

void Date::setMonthNumber(int newMonthNumber)
    {
        monthNumber = newMonthNumber;
    }

int Date::getDay()
    {
        return day;
    }

void Date::setDay(int newDay)
    {
        day = newDay;
    }

int Date::getYear()
    {
        return year;
    }

void Date::setYear(int newYear)
    {
        year = newYear;
    }