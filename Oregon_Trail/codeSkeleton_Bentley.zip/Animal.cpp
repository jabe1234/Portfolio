// CSCI 1300 Fall 2020
// Author: Jay Bentley
// Recitation: 210 - Steven Wilmes
// Project 3

#include <iostream>
#include "Animal.h"
using namespace std;

Animal::Animal()
    {
        animal = "";
        meat = 0;
        bulletRequired = 0;
        chance = 0.0;
    }

Animal::Animal(string newAnimal, int newMeat, int newBulletsRequired, double newChance)
    {
        animal = newAnimal;
        meat = newMeat;
        bulletRequired = newBulletsRequired;
        chance = newChance;
    }

string Animal::getAnimal()
    {
        return animal;
    }

void Animal::setAnimal(string newAnimal)
    {
        animal = newAnimal;
    }
    
int Animal::getMeat()
    {
        return meat;
    }

void Animal::setMeat(int newMeat)
    {
        meat = newMeat;
    }

int Animal::getBullet()
    {
        return bulletRequired;
    }

void Animal::setBullet(int newBullet)
    {
        bulletRequired = newBullet;
    }
    
double Animal::getChance()
    {
        return chance;
    }

void Animal::setChance(double newChance)
    {
        chance = newChance;
    }