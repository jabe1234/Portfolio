// CSCI 1300 Fall 2020
// Author: Jay Bentley
// Recitation: 210 - Steven Wilmes
// Project 3

#include <iostream>
#include "Player.h"
using namespace std;

Player::Player()
    {
        playerName = "";
        oxen = 0;
        food = 0;
        bullets = 0;
        wagonParts = 0;
        medicalAid = 0;
        money = 0.0;
        location = 0;
        for (int i = 0; i < 4; i++)
            {
                companions[i] = "";
            }
        comArrSize = 4;
        living = true;
    }

Player::Player(string newPlayerName, int newOxen, int newFood, int newBullets, int newWagonParts, int newMedicalAid, double newMoney, int newLocation, string newCompanions[], bool newLiving)
    {
        playerName = newPlayerName;
        oxen = newOxen;
        food = newFood;
        bullets = newBullets;
        wagonParts = newWagonParts;
        medicalAid = newMedicalAid;
        money = newMoney;
        location = newLocation;
        for (int i = 0; i < 4; i++)
            {
                companions[i] = newCompanions[i];
            }
        comArrSize = 4;
        living = newLiving;
    }

string Player::getPlayerName()
    {
        return playerName;
    }

void Player::setPlayerName(string newPlayerName)
    {
        playerName = newPlayerName;
    }

int Player::getOxen()
    {
        return oxen;
    }

void Player::setOxen(int newOxen)
    {
        oxen = newOxen;
    }

int Player::getFood()
    {
        return food;
    }

void Player::setFood(int newFood)
    {
        food = newFood;
    }

int Player::getBullets()
    {
        return bullets;
    }

void Player::setBullets(int newBullets)
    {
        bullets = newBullets;
    }

int Player::getWagon()
    {
        return wagonParts;
    }

void Player::setWagon(int newWagon)
    {
        wagonParts = newWagon;
    }

int Player::getMedical()
    {
        return medicalAid;
    }

void Player::setMedical(int newMedical)
    {
        medicalAid = newMedical;
    }

double Player::getMoney()
    {
        return money;
    }

void Player::setMoney(double newMoney)
    {
        money = newMoney;
    }

int Player::getLocation()
    {
        return location;
    }

void Player::setLocation(int newLocation)
    {
        location = newLocation;
    }
    
string Player::getCompanionAt(int index)
    {
        return companions[index];
    }

bool Player::setCompanionAt(int index, string newCompanion)
    {
        if (index >= 0 && index <= 3)
            {
                companions[index] = newCompanion;
            }
    }

int Player::getComArrSize()
    {
        return 4;
    }

void Player::setComArrSize()
    {
        comArrSize = 4;
    }

bool Player::getLiving()
    {
        return living;
    }

void Player::setLiving(bool newLiving)
    {
        living = newLiving;
    }
