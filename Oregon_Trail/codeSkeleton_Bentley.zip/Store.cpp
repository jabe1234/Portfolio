// CSCI 1300 Fall 2020
// Author: Jay Bentley
// Recitation: 210 - Steven Wilmes
// Project 3

#include <iostream>
#include "Store.h"
using namespace std;

Store::Store() // default constructor
    {
        oxenPrice = 0.0;
        foodPrice = 0.0;
        bulletPrice = 0.0;
        wagonPartPrice = 0.0;
        medicalAidPrice = 0.0;
        priceMultiplier = 0.0;
    }

Store::Store(double oxen, double food, double bullet, double wagon, double medical, double price)
    {
        priceMultiplier = price;
        oxenPrice = priceMultiplier * oxen;
        foodPrice = priceMultiplier * food;
        bulletPrice = priceMultiplier * bullet;
        wagonPartPrice  = priceMultiplier * wagon;
        medicalAidPrice = priceMultiplier * medical;
    }

double Store::getOxenPrice()
    {
        return oxenPrice;
    }

void Store::setOxenPrice(double newOxenPrice)
    {
        oxenPrice = priceMultiplier * newOxenPrice;
    }

double Store::getFoodPrice()
    {
        return foodPrice;
    }

void Store::setFoodPrice(double newFoodPrice)
    {
        foodPrice = priceMultiplier * newFoodPrice;
    }

double Store::getBulletPrice()
    {
        return bulletPrice;
    }
    
void Store::setBulletPrice(double newBulletPrice)
    {
        bulletPrice = priceMultiplier * newBulletPrice;
    }

double Store::getWagonPrice()
    {
        return wagonPartPrice;
    }

void Store::setWagonPrice(double newWagonPrice)
    {
        wagonPartPrice = priceMultiplier * newWagonPrice;
    }

double Store::getMedicalPrice()
    {
        return medicalAidPrice;
    }

void Store::setMedicalPrice(double newMedicalPrice)
    {
        medicalAidPrice = priceMultiplier * newMedicalPrice;
    }

double Store::getMultiplier()
    {
        return priceMultiplier;
    }

void Store::setMultiplier(double newMultiplier)
    {
        priceMultiplier = newMultiplier;
    }
