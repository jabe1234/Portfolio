// CSCI 1300 Fall 2020
// Author: Jay Bentley
// Recitation: 210 - Steven Wilmes
// Project 3

#include <iostream>
using namespace std;

#ifndef PLAYER_H
#define PLAYER_H

class Player
{
public:
Player();
Player(string,int,int,int,int,int,double,int,string[],bool);

string getPlayerName();
void setPlayerName(string);

int getOxen();
void setOxen(int);

int getFood();
void setFood(int);

int getBullets();
void setBullets(int);

int getWagon();
void setWagon(int);

int getMedical();
void setMedical(int);

double getMoney();
void setMoney(double);

int getLocation();
void setLocation(int);

string getCompanionAt(int);
bool setCompanionAt(int,string);

int getComArrSize();
void setComArrSize();

bool getLiving();
void setLiving(bool);



private:
string playerName;
int oxen;
int food;
int bullets;
int wagonParts;
int medicalAid;
double money;
int location;
string companions[4];
int comArrSize;
bool living;

};

#endif