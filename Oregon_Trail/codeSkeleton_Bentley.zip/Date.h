// CSCI 1300 Fall 2020
// Author: Jay Bentley
// Recitation: 210 - Steven Wilmes
// Project 3

#include <iostream>
using namespace std;

#ifndef DATE_H
#define DATE_H

class Date
{
public:
Date();
Date(string,int,int,int);

string getMonth();
void setMonth(string);

int getMonthNumber();
void setMonthNumber(int);

int getDay();
void setDay(int);

int getYear();
void setYear(int);

private:;
string month;
int monthNumber;
int day;
int year;

};

#endif